-- 1. 更新现有菜单的 perm
UPDATE "MenuItem" SET perm = 'project:project:list' WHERE id = 4 AND (perm IS NULL OR perm != 'project:project:list');
UPDATE "MenuItem" SET perm = 'crm:organization:list' WHERE id = 2 AND (perm IS NULL OR perm != 'crm:organization:list');
UPDATE "MenuItem" SET perm = 'crm:opportunity:list' WHERE id = 5 AND (perm IS NULL OR perm != 'crm:opportunity:list');
UPDATE "MenuItem" SET perm = 'crm:quotation:list' WHERE id = 20 AND (perm IS NULL OR perm != 'crm:quotation:list');
UPDATE "MenuItem" SET perm = 'finance:expense:list' WHERE id = 9 AND (perm IS NULL OR perm != 'finance:expense:list');
UPDATE "MenuItem" SET perm = 'office:dailyreport:list' WHERE id = 7 AND (perm IS NULL OR perm != 'office:dailyreport:list');
UPDATE "MenuItem" SET perm = 'office:trip:list' WHERE id = 8 AND (perm IS NULL OR perm != 'office:trip:list');

-- 2. 插入所有缺失的 BUTTON 节点
INSERT INTO "MenuItem" (id, key, label, "order", "menuType", perm, "parentId", "isVisible", "requiredRoles", "createdAt", "updatedAt") VALUES
(100, 'org-add',       '创建客户',     1, 'BUTTON', 'crm:organization:add',             2, true, '[]', NOW(), NOW()),
(101, 'org-edit',      '编辑客户',     2, 'BUTTON', 'crm:organization:edit',            2, true, '[]', NOW(), NOW()),
(102, 'org-delete',    '删除客户',     3, 'BUTTON', 'crm:organization:delete',          2, true, '[]', NOW(), NOW()),
(103, 'org-ct-list',   '查看联系人',   4, 'BUTTON', 'crm:organization:contact:list',    2, true, '[]', NOW(), NOW()),
(104, 'org-ct-add',    '添加联系人',   5, 'BUTTON', 'crm:organization:contact:add',     2, true, '[]', NOW(), NOW()),
(105, 'org-ct-edit',   '编辑联系人',   6, 'BUTTON', 'crm:organization:contact:edit',    2, true, '[]', NOW(), NOW()),
(106, 'org-ct-delete', '删除联系人',   7, 'BUTTON', 'crm:organization:contact:delete',  2, true, '[]', NOW(), NOW()),
(110, 'opp-edit',      '编辑售前',     1, 'BUTTON', 'crm:opportunity:edit',             5, true, '[]', NOW(), NOW()),
(120, 'quot-edit',     '编辑报价',     1, 'BUTTON', 'crm:quotation:edit',              20, true, '[]', NOW(), NOW()),
(121, 'quot-approve',  '审批报价',     2, 'BUTTON', 'crm:quotation:approve',           20, true, '[]', NOW(), NOW()),
(130, 'proj-add',      '创建项目',     1, 'BUTTON', 'project:project:add',              4, true, '[]', NOW(), NOW()),
(131, 'proj-edit',     '编辑项目',     2, 'BUTTON', 'project:project:edit',             4, true, '[]', NOW(), NOW()),
(132, 'contract-list',    '查看合同',  3, 'BUTTON', 'project:contract:list',            4, true, '[]', NOW(), NOW()),
(133, 'contract-add',     '创建合同',  4, 'BUTTON', 'project:contract:add',             4, true, '[]', NOW(), NOW()),
(134, 'contract-edit',    '编辑合同',  5, 'BUTTON', 'project:contract:edit',            4, true, '[]', NOW(), NOW()),
(135, 'contract-approve', '审批合同',  6, 'BUTTON', 'project:contract:approve',         4, true, '[]', NOW(), NOW()),
(136, 'contract-delete',  '删除合同',  7, 'BUTTON', 'project:contract:delete',          4, true, '[]', NOW(), NOW()),
(140, 'proc-list',     '查看采购',     8, 'BUTTON', 'project:procurement:list',         4, true, '[]', NOW(), NOW()),
(141, 'proc-edit',     '编辑采购',     9, 'BUTTON', 'project:procurement:edit',         4, true, '[]', NOW(), NOW()),
(142, 'proc-approve',  '审批采购',    10, 'BUTTON', 'project:procurement:approve',      4, true, '[]', NOW(), NOW()),
(145, 'task-edit',     '编辑任务',    11, 'BUTTON', 'project:task:edit',                4, true, '[]', NOW(), NOW()),
(150, 'exp-add',       '创建报销',     1, 'BUTTON', 'finance:expense:add',              9, true, '[]', NOW(), NOW()),
(151, 'exp-edit',      '编辑报销',     2, 'BUTTON', 'finance:expense:edit',             9, true, '[]', NOW(), NOW()),
(152, 'exp-approve',   '审批报销',     3, 'BUTTON', 'finance:expense:approve',          9, true, '[]', NOW(), NOW()),
(160, 'dr-add',        '创建日报',     1, 'BUTTON', 'office:dailyreport:add',           7, true, '[]', NOW(), NOW()),
(161, 'dr-approve',    '审批日报',     2, 'BUTTON', 'office:dailyreport:approve',       7, true, '[]', NOW(), NOW()),
(170, 'trip-add',      '创建出差',     1, 'BUTTON', 'office:trip:add',                  8, true, '[]', NOW(), NOW()),
(171, 'trip-approve',  '审批出差',     2, 'BUTTON', 'office:trip:approve',              8, true, '[]', NOW(), NOW()),
(180, 'user-add',      '创建用户',     1, 'BUTTON', 'system:user:add',                 11, true, '[]', NOW(), NOW()),
(181, 'user-edit',     '编辑用户',     2, 'BUTTON', 'system:user:edit',                11, true, '[]', NOW(), NOW()),
(182, 'user-delete',   '删除用户',     3, 'BUTTON', 'system:user:delete',              11, true, '[]', NOW(), NOW()),
(185, 'role-add',      '创建角色',     1, 'BUTTON', 'system:role:add',                 12, true, '[]', NOW(), NOW()),
(186, 'role-edit',     '编辑角色',     2, 'BUTTON', 'system:role:edit',                12, true, '[]', NOW(), NOW()),
(187, 'role-delete',   '删除角色',     3, 'BUTTON', 'system:role:delete',              12, true, '[]', NOW(), NOW()),
(190, 'menu-add',      '创建菜单',     1, 'BUTTON', 'system:menu:add',                 13, true, '[]', NOW(), NOW()),
(191, 'menu-edit',     '编辑菜单',     2, 'BUTTON', 'system:menu:edit',                13, true, '[]', NOW(), NOW()),
(192, 'menu-delete',   '删除菜单',     3, 'BUTTON', 'system:menu:delete',              13, true, '[]', NOW(), NOW()),
(195, 'dept-add',      '创建部门',     1, 'BUTTON', 'system:department:add',           14, true, '[]', NOW(), NOW()),
(196, 'dept-edit',     '编辑部门',     2, 'BUTTON', 'system:department:edit',          14, true, '[]', NOW(), NOW()),
(197, 'dept-delete',   '删除部门',     3, 'BUTTON', 'system:department:delete',        14, true, '[]', NOW(), NOW()),
(200, 'dict-add',      '创建字典',     1, 'BUTTON', 'system:dict:add',                 15, true, '[]', NOW(), NOW()),
(201, 'dict-edit',     '编辑字典',     2, 'BUTTON', 'system:dict:edit',                15, true, '[]', NOW(), NOW()),
(202, 'dict-delete',   '删除字典',     3, 'BUTTON', 'system:dict:delete',              15, true, '[]', NOW(), NOW()),
(205, 'log-delete',    '清理日志',     1, 'BUTTON', 'system:log:delete',               17, true, '[]', NOW(), NOW()),
(210, 'settings-edit', '编辑设置',     5, 'BUTTON', 'system:settings:edit',            10, true, '[]', NOW(), NOW());

-- 3. 为管理员角色分配所有新 BUTTON
INSERT INTO "RoleMenu" ("roleId", "menuId", "createdAt", "updatedAt")
SELECT 1, id, NOW(), NOW() FROM "MenuItem" WHERE id >= 100
ON CONFLICT DO NOTHING;

-- 验证
SELECT id, label, perm, "parentId", "menuType" FROM "MenuItem" ORDER BY "parentId", id;
